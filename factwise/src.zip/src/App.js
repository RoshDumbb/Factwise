
import './App.css';
import MultipleSelect from "./Components/page";

function App() {
  return (
    <div className="App">
      {/* <Page/> */}
      <MultipleSelect/>
    </div>
  );
}

export default App;
